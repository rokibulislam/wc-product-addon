﻿=== Product Addon Custom Field For Woocommerce ===
Author:            Md Rokibul islam
Author URI:        https://profiles.wordpress.org/rokibul-islam/
Contributors:      rokibul-islam
Tags:              woocommerce, woocommerce custom fields, Woocommerce Product Addons, woocommerce product options
Requires at least: 5.6
Tested up to:      6.4
Stable tag:        1.0.0
License:           GPLv2 or later
License URI:       http://www.gnu.org/licenses/gpl-2.0.html

== Description ==
Product Addon Custom Field For Woocommerce is drag and drop custom form builder plugin which will allow adding extra field in product.

== Features ==
* Drag and Drop Form Builder For Adding Field in Product

== FORM FIELDS AVAILABLE IN Contact ==
* Text Field
* Textara Field
* Email Field
* Checkbox Field
* Radio Field
* DropDown / Select Field
* Multi Dropdown / MultiSelect Field
* Date Field
* Numeric Field
* Image Field